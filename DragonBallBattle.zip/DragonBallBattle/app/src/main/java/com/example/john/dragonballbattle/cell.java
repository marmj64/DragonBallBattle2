package com.example.john.dragonballbattle;

/**
 * Created by John on 5/2/2018.
 */

public class cell extends Fighter implements FighterMoves {

    public cell(){
        super("cell", 200, "Death Beam", "Super Kamehameha", "Instant Transmission", "Self Destruction");
    }

    // @Override
    public static String getFighterName() {
        return null;
    }

    @Override
    public int normalAttack() {
        return 50 ;
    }

    @Override
    public int strongAttack() {
        return 75;
    }
    @Override
    public String defenseAttack() {
        return "Opposing Player Looses Turn";
    }

    @Override
    public String specialAttack() {
        return "cell Loses Half Health. Opponent Lose 100 HP";
    }
}
