package com.example.john.dragonballbattle;

/**
 * Created by John on 5/2/2018.
 */

public class kidbuu extends Fighter implements FighterMoves {

    public kidbuu(){
        //TEST
        super("kidbuu", 200, "Shocking Ball", "Planet Burst", "Regeneration", "Absorption");
    }

    // @Override
    public static String getFighterName() {
        return null;
    }

    @Override
    public int normalAttack() {
        return 50;
    }

    @Override
    public int strongAttack() {
        return 75;
        //add accuracy for the attack
    }

    @Override
    public String defenseAttack() {
        return "Regenerate 50 HP";
    }

    @Override
    public String specialAttack() {
        return "Opponent Loses 25 HP. Buu Gains 25 HP";
    }
}
