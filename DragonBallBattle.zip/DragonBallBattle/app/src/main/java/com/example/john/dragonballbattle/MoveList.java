package com.example.john.dragonballbattle;

/**
 * Created by John on 4/19/2018.
 */

public class MoveList {

    public static String gokuKaioken(){
        return "Strong Attack Is Twice As Strong";
    }

    public static int gokuKamehameha(){
        return 75;
    }

    public static String gokuInstantTransmission(){
        return "Opposing Player Looses Turn";
    }

    public static int gokuSpiritBomb(){
        return 125;
    }
}
